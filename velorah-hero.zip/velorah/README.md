# Velorah — Hero Section

Single-page hero with fullscreen looping video background, glassmorphic navigation, and cinematic typography. Built with React + Vite + TypeScript + Tailwind CSS + shadcn/ui.

## Setup

```bash
npm install
npm run dev
```

Then open the printed local URL (typically http://localhost:5173).

## Build

```bash
npm run build
npm run preview
```

## Structure

- `src/components/Navigation.tsx` — glassmorphic nav bar (logo, links, CTA)
- `src/components/Hero.tsx` — fullscreen video hero with cinematic type and CTA
- `src/components/ui/button.tsx` — shadcn/ui Button, extended with a `glass` variant for the liquid-glass effect
- `src/index.css` — theme tokens (HSL CSS variables), Google Fonts, `.liquid-glass`, and `fade-rise` keyframe animations
- `tailwind.config.js` — Tailwind theme wired to the CSS variables

## Notes

- The video is loaded from the CloudFront URL supplied in the brief; swap `VIDEO_SRC` in `Hero.tsx` to change it.
- Fonts (Instrument Serif + Inter) are loaded via Google Fonts `<link>` tags in `index.html`.
- Respects `prefers-reduced-motion` by disabling the fade-rise entrance animations.
