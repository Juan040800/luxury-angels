import { Button } from "@/components/ui/button";

const navLinks = [
  { label: "Home", href: "#", active: true },
  { label: "Studio", href: "#" },
  { label: "About", href: "#" },
  { label: "Journal", href: "#" },
  { label: "Reach Us", href: "#" },
];

export function Navigation() {
  return (
    <nav className="relative z-10 flex flex-row items-center justify-between px-8 py-6 max-w-7xl mx-auto">
      <a
        href="#"
        className="text-3xl tracking-tight text-foreground"
        style={{ fontFamily: "'Instrument Serif', serif" }}
      >
        Velorah<sup className="text-xs">®</sup>
      </a>

      <div className="hidden md:flex items-center gap-8">
        {navLinks.map((link) => (
          <a
            key={link.label}
            href={link.href}
            className={
              link.active
                ? "text-sm text-foreground transition-colors"
                : "text-sm text-muted-foreground hover:text-foreground transition-colors"
            }
          >
            {link.label}
          </a>
        ))}
      </div>

      <Button
        variant="glass"
        className="rounded-full px-6 py-2.5 h-auto text-sm text-foreground"
      >
        Begin Journey
      </Button>
    </nav>
  );
}
