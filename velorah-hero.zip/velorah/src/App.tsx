import { Navigation } from "@/components/Navigation";
import { Hero } from "@/components/Hero";

function App() {
  return (
    <div className="min-h-screen bg-background font-body">
      <Navigation />
      <Hero />
    </div>
  );
}

export default App;
